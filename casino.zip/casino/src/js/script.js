(function ($) {
    'use strict'

    $(document).ready(function () {
        svg4everybody({})
        $('.pane-inner-block__text').on('click'), function () {
            $('.hide-text').slideUp(300);
        }
    })
})(jQuery)
//=require partials/google_page_speed.js